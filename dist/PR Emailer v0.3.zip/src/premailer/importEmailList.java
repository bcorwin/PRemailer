/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package premailer;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import jxl.Cell;
import jxl.CellType;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

/**
 *
 * @author bcorwin
 */
public class importEmailList {
    private String inputFile;
    private Workbook w;
    
    public void setInputFile(String inputFile) throws IOException {
        this.inputFile = inputFile;
        File inputWorkbook = new File(inputFile);
        try {
            w = Workbook.getWorkbook(inputWorkbook);
        } catch (BiffException e) {
            e.printStackTrace();
        }
    }
    public String[] readCol(String sheetName, String col, Boolean noEmpty) {
        List<String> colList = new ArrayList<String>();
        //Check that sheet exists
        String sheetList = Arrays.toString(w.getSheetNames());
        if(sheetList.contains(sheetName) == false) {
            throw new Error("Missing required sheet, '" + sheetName + "'.");
        }
        else {
            Sheet body = w.getSheet(sheetName);

            //Get col number if given a name else use that number
            int colNum = -1;
            try {
                colNum = Integer.parseInt(col);
            } catch (NumberFormatException e) {
                String chkCell;
                col = col.toUpperCase().trim();
                for (int c = 0; c < body.getColumns(); c++) {
                    chkCell = body.getCell(c,0).getContents().toUpperCase().trim();
                    if(chkCell.equals(col)) {
                        colNum = c;
                        //Known possible error. If there are more than one column names
                        break;
                    }
                }
                if(colNum == -1) {
                    throw new Error("Column '" + col
                            + "' does not exist in sheet '" + sheetName + "'.");
                }
            }

            for (int i = 0; i < body.getRows(); i++) {
                Cell cell = body.getCell(colNum, i);
                if (cell.getType() != CellType.EMPTY | noEmpty == false) {
                    colList.add(cell.getContents());
                }
            }
        }
        String[] output = colList.toArray(new String[colList.size()]);
        return output;
    }
}
