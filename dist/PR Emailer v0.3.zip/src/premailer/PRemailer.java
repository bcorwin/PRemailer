/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package premailer;

import java.io.IOException;

/**
 *
 * @author bcorwin
 */
public class PRemailer {

    /**
     * @param args the command line arguments
     */
    public static String[] genEmailBody(String filename) {
        importEmailList inputFile = new importEmailList();
        try {
            inputFile.setInputFile(filename);
            String[] emailBody;
            emailBody = inputFile.readCol("Email Body", "0", false);
            return emailBody;
        } catch(IOException e) {
            throw new Error("Error reading file. May not exist or not in xls format.");
        }
    }
    
    public static Agency[] genAgencies(String filename) {
        importEmailList inputFile = new importEmailList();
        try {
            inputFile.setInputFile(filename);
            String[] agencyList, nameList, timeList, roleList, noteList;
            agencyList = inputFile.readCol("Actor List", "Agency", true);
            nameList = inputFile.readCol("Actor List", "Name", true);
            timeList = inputFile.readCol("Actor List", "Time", true);
            roleList = inputFile.readCol("Actor List", "Role", true);
            noteList = inputFile.readCol("Actor List", "Notes", false);
            
            String[] allAgencies, allAgents, allEmails;
            allAgencies = inputFile.readCol("Agency List", "Agency", true);
            allAgents = inputFile.readCol("Agency List", "Agent Names", true);
            allEmails = inputFile.readCol("Agency List", "Agent Emails", true);
            
            //Build list of agencies
            Agency [] agencies = new Agency[allAgencies.length - 1];
            for(int agnt = 1; agnt < allAgencies.length; agnt++) {
                agencies[agnt-1] = new Agency(allAgencies[agnt], allAgents[agnt], allEmails[agnt]);
                //Build tables
                for(int row = 1; row < agencyList.length; row++) {
                    if(agencies[agnt-1].Agency.equals(agencyList[row])) {
                        agencies[agnt-1].addRow(timeList[row], nameList[row], roleList[row], noteList[row]);
                    }
                }
            }
            return agencies;
            
        } catch(IOException e) {
            throw new Error();
        }
    }  
}
