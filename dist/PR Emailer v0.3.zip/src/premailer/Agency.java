/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package premailer;

import java.util.stream.IntStream;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

/**
 *
 * @author bcorwin
 */
public class Agency {
    public String Agency, Names, Emails, Subject, Body;
    public String[][] Table = new String[1][5];
    
    public Agency (String setAgency, String setNames, String setEmails) {
        Agency = setAgency;
        Names = setNames;
        Emails = setEmails;
        //To do, make it so you can pick the order by rearranging the columns in excel
        Table[0][0] = "Time";
        Table[0][1] = "Name";
        Table[0][2] = "Agency";
        Table[0][3] = "Role";
        Table[0][4] = "Notes";
    }

    Agency() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void addRow(String time, String name, String role, String note) {
        int newRow = this.Table.length;
        String[][] newTable = new String[newRow + 1][5];
        System.arraycopy(this.Table, 0, newTable, 0, newRow);
        newTable[newRow][0] = time;
        newTable[newRow][1] = name;
        newTable[newRow][2] = this.Agency;
        newTable[newRow][3] = role;
        newTable[newRow][4] = note;
        this.Table = newTable;
    }
    public String printTable() {
        int[] maxWidths = new int[5];
        String output = "";
        int len, totLen;
        for(int col = 0; col < 5; col++) {
            for(int row = 0; row < this.Table.length; row++) {
                len = this.Table[row][col].length();
                if(len > maxWidths[col]) {
                    maxWidths[col] = len;
                }
            }
        }
        totLen = IntStream.of(maxWidths).sum();
        
        String colFormat;
        for(int row = 0; row < this.Table.length; row++) {
            for(int col = 0; col < this.Table[row].length; col++) {
                colFormat = "| %" + maxWidths[col] +"s";
                output = output + String.format(colFormat, this.Table[row][col]);
            }
            output = output + "|";
            output = output + "\n";
        }
        return output;
    }
    public String createHTMLtable() {
        String output = "<table align = \"center\" style = \"width:500px\">";
        for(int rowNum = 0; rowNum < this.Table.length; rowNum++) {
            String[] row = this.Table[rowNum];
            output = output + "<tr>";
            for(int col = 0; col < row.length; col++) {
                if(rowNum == 0) {
                    output = output + "<th>" + row[col] + "</th>";
                } else {
                    output = output + "<td align = \"center\">" + row[col] + "</td>";
                }
            }
            output = output + "</tr>";
        }
        output = output + "</table>";
        return output;
    }
    public void sortTable(String varName){

    }
    
    public void setEmail(String[] emailBody) {
        String newLine, subject = "", body = "<!DOCTYPE html><html><head><style>"
                + "table,th,td{border:1px solid black;border-collapse:collapse;}"
                + "</style></head>";
        for(int line = 0; line < emailBody.length; line++) {
            newLine = emailBody[line].replaceAll("\\<(?i)LIST\\>", this.createHTMLtable());
            newLine = newLine.replaceAll("\\<(?i)AGNTNAME\\>", this.Names);
            if(line == 0) {
                subject = newLine;
            } else {
                if("".equals(newLine)) newLine = "<br>";
                body = body + newLine + "<br>";
            }
        }
        body = body + "</body></html>";
        this.Body = body;
        this.Subject = subject;
    }
    
    public String sendEmail(String from, String pass, String cc, String testEmail) {
        String output = "";
        String[] to;
        if("".equals(testEmail)) to = this.Emails.split(",");
            else to = testEmail.split(",");

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
            new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(from, pass);
                }
            }
        );
        
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            for(String currTo: to) {
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(currTo));
            }
            if(!"".equals(cc)) message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc));
            message.setSubject(this.Subject);
            message.setContent(this.Body, "text/html");
            Transport.send(message);
            output += "Message successfully sent to " + this.Agency
                    + " (" + Arrays.toString(to) + ").<br>";
        } catch (MessagingException mex) {
            output += "<font color = \"red\">Email failed to send for "
                    + this.Agency + " (" + Arrays.toString(to) + ").</font>";
      }
        return output;
   }
}
